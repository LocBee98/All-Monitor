﻿
namespace AppMonitor
{
    partial class Stations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelNguyetMinh2 = new AppMonitor.CustemItems.CustomPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.panelAriyana = new AppMonitor.CustemItems.CustomPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.panelGiayAH = new AppMonitor.CustemItems.CustomPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panelSabeco = new AppMonitor.CustemItems.CustomPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.panelTC1 = new AppMonitor.CustemItems.CustomPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panelMinhTien = new AppMonitor.CustemItems.CustomPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.panelMinhTuan = new AppMonitor.CustemItems.CustomPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panelETC = new AppMonitor.CustemItems.CustomPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panelPhuTan = new AppMonitor.CustemItems.CustomPanel();
            this.label51 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelNumberPhuTan = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.panelNhomMD = new AppMonitor.CustemItems.CustomPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panelTA = new AppMonitor.CustemItems.CustomPanel();
            this.label53 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.labelThuyAnh = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.panelAcecook = new AppMonitor.CustemItems.CustomPanel();
            this.label56 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.labelNumberAcecook = new System.Windows.Forms.Label();
            this.panelTC3 = new AppMonitor.CustemItems.CustomPanel();
            this.label42 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.labelNumberTC3 = new System.Windows.Forms.Label();
            this.panelSaiSon = new AppMonitor.CustemItems.CustomPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.labelNumberSaiSon = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.panelHL = new AppMonitor.CustemItems.CustomPanel();
            this.label48 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.labelNumberHL = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panelTS = new AppMonitor.CustemItems.CustomPanel();
            this.label45 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.labelNumberTS = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panelVN = new AppMonitor.CustemItems.CustomPanel();
            this.label46 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.labelNumberVN = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.panelVicemHV = new AppMonitor.CustemItems.CustomPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.labelNumberHV = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panelNhomCT = new AppMonitor.CustemItems.CustomPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panelCuongThinh = new AppMonitor.CustemItems.CustomPanel();
            this.label26 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelDuyenLinh = new AppMonitor.CustemItems.CustomPanel();
            this.label24 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panelNguyetMinh2.SuspendLayout();
            this.panelAriyana.SuspendLayout();
            this.panelGiayAH.SuspendLayout();
            this.panelSabeco.SuspendLayout();
            this.panelTC1.SuspendLayout();
            this.panelMinhTien.SuspendLayout();
            this.panelMinhTuan.SuspendLayout();
            this.panelETC.SuspendLayout();
            this.panelPhuTan.SuspendLayout();
            this.panelNhomMD.SuspendLayout();
            this.panelTA.SuspendLayout();
            this.panelAcecook.SuspendLayout();
            this.panelTC3.SuspendLayout();
            this.panelSaiSon.SuspendLayout();
            this.panelHL.SuspendLayout();
            this.panelTS.SuspendLayout();
            this.panelVN.SuspendLayout();
            this.panelVicemHV.SuspendLayout();
            this.panelNhomCT.SuspendLayout();
            this.panelCuongThinh.SuspendLayout();
            this.panelDuyenLinh.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panelNguyetMinh2
            // 
            this.panelNguyetMinh2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelNguyetMinh2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelNguyetMinh2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelNguyetMinh2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelNguyetMinh2.BorderRadius = 5;
            this.panelNguyetMinh2.BorderSize = 0;
            this.panelNguyetMinh2.Controls.Add(this.label8);
            this.panelNguyetMinh2.ForeColor = System.Drawing.Color.White;
            this.panelNguyetMinh2.Location = new System.Drawing.Point(1332, 26);
            this.panelNguyetMinh2.Name = "panelNguyetMinh2";
            this.panelNguyetMinh2.Size = new System.Drawing.Size(200, 80);
            this.panelNguyetMinh2.TabIndex = 0;
            this.panelNguyetMinh2.TextColor = System.Drawing.Color.White;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(24, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 23);
            this.label8.TabIndex = 0;
            this.label8.Text = "NGUYỆT MINH 2";
            // 
            // panelAriyana
            // 
            this.panelAriyana.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelAriyana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(139)))), ((int)(((byte)(227)))));
            this.panelAriyana.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(139)))), ((int)(((byte)(227)))));
            this.panelAriyana.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelAriyana.BorderRadius = 5;
            this.panelAriyana.BorderSize = 0;
            this.panelAriyana.Controls.Add(this.label16);
            this.panelAriyana.ForeColor = System.Drawing.Color.White;
            this.panelAriyana.Location = new System.Drawing.Point(1332, 152);
            this.panelAriyana.Name = "panelAriyana";
            this.panelAriyana.Size = new System.Drawing.Size(200, 80);
            this.panelAriyana.TabIndex = 0;
            this.panelAriyana.TextColor = System.Drawing.Color.White;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(56, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 23);
            this.label16.TabIndex = 0;
            this.label16.Text = "ARIYANA";
            // 
            // panelGiayAH
            // 
            this.panelGiayAH.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelGiayAH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelGiayAH.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelGiayAH.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelGiayAH.BorderRadius = 5;
            this.panelGiayAH.BorderSize = 0;
            this.panelGiayAH.Controls.Add(this.label30);
            this.panelGiayAH.Controls.Add(this.label6);
            this.panelGiayAH.ForeColor = System.Drawing.Color.White;
            this.panelGiayAH.Location = new System.Drawing.Point(1068, 26);
            this.panelGiayAH.Name = "panelGiayAH";
            this.panelGiayAH.Size = new System.Drawing.Size(200, 80);
            this.panelGiayAH.TabIndex = 0;
            this.panelGiayAH.TextColor = System.Drawing.Color.White;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(56, 38);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(91, 23);
            this.label30.TabIndex = 0;
            this.label30.Text = " AN HÒA";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(78, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 23);
            this.label6.TabIndex = 0;
            this.label6.Text = "GIẤY";
            // 
            // panelSabeco
            // 
            this.panelSabeco.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelSabeco.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(139)))), ((int)(((byte)(227)))));
            this.panelSabeco.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(139)))), ((int)(((byte)(227)))));
            this.panelSabeco.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelSabeco.BorderRadius = 5;
            this.panelSabeco.BorderSize = 0;
            this.panelSabeco.Controls.Add(this.label7);
            this.panelSabeco.ForeColor = System.Drawing.Color.White;
            this.panelSabeco.Location = new System.Drawing.Point(1068, 152);
            this.panelSabeco.Name = "panelSabeco";
            this.panelSabeco.Size = new System.Drawing.Size(200, 80);
            this.panelSabeco.TabIndex = 0;
            this.panelSabeco.TextColor = System.Drawing.Color.White;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(62, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 23);
            this.label7.TabIndex = 0;
            this.label7.Text = "SABECO";
            // 
            // panelTC1
            // 
            this.panelTC1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelTC1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTC1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTC1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelTC1.BorderRadius = 5;
            this.panelTC1.BorderSize = 0;
            this.panelTC1.Controls.Add(this.label29);
            this.panelTC1.Controls.Add(this.label5);
            this.panelTC1.ForeColor = System.Drawing.Color.White;
            this.panelTC1.Location = new System.Drawing.Point(804, 26);
            this.panelTC1.Name = "panelTC1";
            this.panelTC1.Size = new System.Drawing.Size(200, 80);
            this.panelTC1.TabIndex = 0;
            this.panelTC1.TextColor = System.Drawing.Color.White;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(19, 38);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(159, 23);
            this.label29.TabIndex = 0;
            this.label29.Text = " THÀNH CÔNG 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(83, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "XM";
            // 
            // panelMinhTien
            // 
            this.panelMinhTien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelMinhTien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelMinhTien.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelMinhTien.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelMinhTien.BorderRadius = 5;
            this.panelMinhTien.BorderSize = 0;
            this.panelMinhTien.Controls.Add(this.label15);
            this.panelMinhTien.ForeColor = System.Drawing.Color.White;
            this.panelMinhTien.Location = new System.Drawing.Point(804, 152);
            this.panelMinhTien.Name = "panelMinhTien";
            this.panelMinhTien.Size = new System.Drawing.Size(200, 80);
            this.panelMinhTien.TabIndex = 0;
            this.panelMinhTien.TextColor = System.Drawing.Color.White;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(50, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 23);
            this.label15.TabIndex = 0;
            this.label15.Text = "MINH TIẾN";
            // 
            // panelMinhTuan
            // 
            this.panelMinhTuan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelMinhTuan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelMinhTuan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelMinhTuan.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelMinhTuan.BorderRadius = 5;
            this.panelMinhTuan.BorderSize = 0;
            this.panelMinhTuan.Controls.Add(this.label28);
            this.panelMinhTuan.Controls.Add(this.label4);
            this.panelMinhTuan.ForeColor = System.Drawing.Color.White;
            this.panelMinhTuan.Location = new System.Drawing.Point(540, 26);
            this.panelMinhTuan.Name = "panelMinhTuan";
            this.panelMinhTuan.Size = new System.Drawing.Size(200, 80);
            this.panelMinhTuan.TabIndex = 0;
            this.panelMinhTuan.TextColor = System.Drawing.Color.White;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(42, 38);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(111, 23);
            this.label28.TabIndex = 0;
            this.label28.Text = "MINH TUẤN";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(82, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "XM ";
            // 
            // panelETC
            // 
            this.panelETC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelETC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelETC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelETC.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelETC.BorderRadius = 5;
            this.panelETC.BorderSize = 0;
            this.panelETC.Controls.Add(this.label14);
            this.panelETC.Controls.Add(this.label13);
            this.panelETC.ForeColor = System.Drawing.Color.White;
            this.panelETC.Location = new System.Drawing.Point(540, 152);
            this.panelETC.Name = "panelETC";
            this.panelETC.Size = new System.Drawing.Size(200, 80);
            this.panelETC.TabIndex = 0;
            this.panelETC.TextColor = System.Drawing.Color.White;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(57, 40);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 23);
            this.label14.TabIndex = 0;
            this.label14.Text = "NAM ĐỊNH";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(80, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 23);
            this.label13.TabIndex = 0;
            this.label13.Text = "ETC";
            // 
            // panelPhuTan
            // 
            this.panelPhuTan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelPhuTan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelPhuTan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelPhuTan.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelPhuTan.BorderRadius = 5;
            this.panelPhuTan.BorderSize = 0;
            this.panelPhuTan.Controls.Add(this.label51);
            this.panelPhuTan.Controls.Add(this.label3);
            this.panelPhuTan.Controls.Add(this.labelNumberPhuTan);
            this.panelPhuTan.Controls.Add(this.label50);
            this.panelPhuTan.ForeColor = System.Drawing.Color.White;
            this.panelPhuTan.Location = new System.Drawing.Point(498, 346);
            this.panelPhuTan.Name = "panelPhuTan";
            this.panelPhuTan.Size = new System.Drawing.Size(220, 120);
            this.panelPhuTan.TabIndex = 0;
            this.panelPhuTan.TextColor = System.Drawing.Color.White;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(121, 67);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(35, 40);
            this.label51.TabIndex = 0;
            this.label51.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "XM PHÚ TÂN";
            // 
            // labelNumberPhuTan
            // 
            this.labelNumberPhuTan.AutoSize = true;
            this.labelNumberPhuTan.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberPhuTan.Location = new System.Drawing.Point(54, 50);
            this.labelNumberPhuTan.Name = "labelNumberPhuTan";
            this.labelNumberPhuTan.Size = new System.Drawing.Size(35, 40);
            this.labelNumberPhuTan.TabIndex = 0;
            this.labelNumberPhuTan.Text = "2";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(85, 43);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(47, 58);
            this.label50.TabIndex = 0;
            this.label50.Text = "/";
            // 
            // panelNhomMD
            // 
            this.panelNhomMD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelNhomMD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelNhomMD.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelNhomMD.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelNhomMD.BorderRadius = 5;
            this.panelNhomMD.BorderSize = 0;
            this.panelNhomMD.Controls.Add(this.label11);
            this.panelNhomMD.Controls.Add(this.label12);
            this.panelNhomMD.ForeColor = System.Drawing.Color.White;
            this.panelNhomMD.Location = new System.Drawing.Point(276, 152);
            this.panelNhomMD.Name = "panelNhomMD";
            this.panelNhomMD.Size = new System.Drawing.Size(200, 80);
            this.panelNhomMD.TabIndex = 0;
            this.panelNhomMD.TextColor = System.Drawing.Color.White;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(38, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 23);
            this.label11.TabIndex = 1;
            this.label11.Text = "MINH DŨNG";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(61, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 23);
            this.label12.TabIndex = 2;
            this.label12.Text = "NHÔM";
            // 
            // panelTA
            // 
            this.panelTA.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelTA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTA.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTA.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelTA.BorderRadius = 5;
            this.panelTA.BorderSize = 0;
            this.panelTA.Controls.Add(this.label53);
            this.panelTA.Controls.Add(this.label20);
            this.panelTA.Controls.Add(this.labelThuyAnh);
            this.panelTA.Controls.Add(this.label52);
            this.panelTA.ForeColor = System.Drawing.Color.White;
            this.panelTA.Location = new System.Drawing.Point(984, 346);
            this.panelTA.Name = "panelTA";
            this.panelTA.Size = new System.Drawing.Size(220, 120);
            this.panelTA.TabIndex = 0;
            this.panelTA.TextColor = System.Drawing.Color.White;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(125, 67);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(35, 40);
            this.label53.TabIndex = 0;
            this.label53.Text = "3";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(44, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(138, 23);
            this.label20.TabIndex = 0;
            this.label20.Text = "NM THỦY ANH";
            // 
            // labelThuyAnh
            // 
            this.labelThuyAnh.AutoSize = true;
            this.labelThuyAnh.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThuyAnh.Location = new System.Drawing.Point(58, 50);
            this.labelThuyAnh.Name = "labelThuyAnh";
            this.labelThuyAnh.Size = new System.Drawing.Size(35, 40);
            this.labelThuyAnh.TabIndex = 0;
            this.labelThuyAnh.Text = "3";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(89, 43);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(47, 58);
            this.label52.TabIndex = 0;
            this.label52.Text = "/";
            // 
            // panelAcecook
            // 
            this.panelAcecook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelAcecook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(24)))), ((int)(((byte)(195)))));
            this.panelAcecook.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(24)))), ((int)(((byte)(195)))));
            this.panelAcecook.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelAcecook.BorderRadius = 5;
            this.panelAcecook.BorderSize = 0;
            this.panelAcecook.Controls.Add(this.label56);
            this.panelAcecook.Controls.Add(this.label21);
            this.panelAcecook.Controls.Add(this.label54);
            this.panelAcecook.Controls.Add(this.labelNumberAcecook);
            this.panelAcecook.ForeColor = System.Drawing.Color.White;
            this.panelAcecook.Location = new System.Drawing.Point(1227, 345);
            this.panelAcecook.Name = "panelAcecook";
            this.panelAcecook.Size = new System.Drawing.Size(300, 120);
            this.panelAcecook.TabIndex = 0;
            this.panelAcecook.TextColor = System.Drawing.Color.White;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(159, 69);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 40);
            this.label56.TabIndex = 0;
            this.label56.Text = "3";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(43, 21);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(210, 23);
            this.label21.TabIndex = 0;
            this.label21.Text = "ACECOOK HƯNG YÊN";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(123, 45);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(47, 58);
            this.label54.TabIndex = 0;
            this.label54.Text = "/";
            // 
            // labelNumberAcecook
            // 
            this.labelNumberAcecook.AutoSize = true;
            this.labelNumberAcecook.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberAcecook.Location = new System.Drawing.Point(92, 52);
            this.labelNumberAcecook.Name = "labelNumberAcecook";
            this.labelNumberAcecook.Size = new System.Drawing.Size(35, 40);
            this.labelNumberAcecook.TabIndex = 0;
            this.labelNumberAcecook.Text = "0";
            // 
            // panelTC3
            // 
            this.panelTC3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelTC3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTC3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTC3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelTC3.BorderRadius = 5;
            this.panelTC3.BorderSize = 0;
            this.panelTC3.Controls.Add(this.label42);
            this.panelTC3.Controls.Add(this.label19);
            this.panelTC3.Controls.Add(this.label38);
            this.panelTC3.Controls.Add(this.labelNumberTC3);
            this.panelTC3.ForeColor = System.Drawing.Color.White;
            this.panelTC3.Location = new System.Drawing.Point(741, 346);
            this.panelTC3.Name = "panelTC3";
            this.panelTC3.Size = new System.Drawing.Size(220, 120);
            this.panelTC3.TabIndex = 0;
            this.panelTC3.TextColor = System.Drawing.Color.White;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(112, 66);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(35, 40);
            this.label42.TabIndex = 0;
            this.label42.Text = "2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(14, 21);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(189, 23);
            this.label19.TabIndex = 0;
            this.label19.Text = "XM THÀNH CÔNG 3";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(76, 42);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(47, 58);
            this.label38.TabIndex = 0;
            this.label38.Text = "/";
            // 
            // labelNumberTC3
            // 
            this.labelNumberTC3.AutoSize = true;
            this.labelNumberTC3.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberTC3.Location = new System.Drawing.Point(45, 49);
            this.labelNumberTC3.Name = "labelNumberTC3";
            this.labelNumberTC3.Size = new System.Drawing.Size(35, 40);
            this.labelNumberTC3.TabIndex = 0;
            this.labelNumberTC3.Text = "2";
            // 
            // panelSaiSon
            // 
            this.panelSaiSon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelSaiSon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelSaiSon.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelSaiSon.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelSaiSon.BorderRadius = 5;
            this.panelSaiSon.BorderSize = 0;
            this.panelSaiSon.Controls.Add(this.label33);
            this.panelSaiSon.Controls.Add(this.label18);
            this.panelSaiSon.Controls.Add(this.labelNumberSaiSon);
            this.panelSaiSon.Controls.Add(this.label31);
            this.panelSaiSon.ForeColor = System.Drawing.Color.White;
            this.panelSaiSon.Location = new System.Drawing.Point(255, 345);
            this.panelSaiSon.Name = "panelSaiSon";
            this.panelSaiSon.Size = new System.Drawing.Size(220, 120);
            this.panelSaiSon.TabIndex = 0;
            this.panelSaiSon.TextColor = System.Drawing.Color.White;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(110, 68);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 40);
            this.label33.TabIndex = 0;
            this.label33.Text = "2";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(46, 21);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(117, 23);
            this.label18.TabIndex = 0;
            this.label18.Text = "XM SÀI SƠN";
            // 
            // labelNumberSaiSon
            // 
            this.labelNumberSaiSon.AutoSize = true;
            this.labelNumberSaiSon.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberSaiSon.Location = new System.Drawing.Point(43, 51);
            this.labelNumberSaiSon.Name = "labelNumberSaiSon";
            this.labelNumberSaiSon.Size = new System.Drawing.Size(35, 40);
            this.labelNumberSaiSon.TabIndex = 0;
            this.labelNumberSaiSon.Text = "2";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(74, 44);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(47, 58);
            this.label31.TabIndex = 0;
            this.label31.Text = "/";
            // 
            // panelHL
            // 
            this.panelHL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelHL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelHL.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelHL.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelHL.BorderRadius = 5;
            this.panelHL.BorderSize = 0;
            this.panelHL.Controls.Add(this.label48);
            this.panelHL.Controls.Add(this.label25);
            this.panelHL.Controls.Add(this.labelNumberHL);
            this.panelHL.Controls.Add(this.label35);
            this.panelHL.ForeColor = System.Drawing.Color.White;
            this.panelHL.Location = new System.Drawing.Point(1132, 598);
            this.panelHL.Name = "panelHL";
            this.panelHL.Size = new System.Drawing.Size(400, 120);
            this.panelHL.TabIndex = 0;
            this.panelHL.TextColor = System.Drawing.Color.White;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(220, 65);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(35, 40);
            this.label48.TabIndex = 0;
            this.label48.Text = "4";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(116, 13);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(177, 23);
            this.label25.TabIndex = 0;
            this.label25.Text = "XM HOÀNG LONG";
            // 
            // labelNumberHL
            // 
            this.labelNumberHL.AutoSize = true;
            this.labelNumberHL.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberHL.Location = new System.Drawing.Point(153, 48);
            this.labelNumberHL.Name = "labelNumberHL";
            this.labelNumberHL.Size = new System.Drawing.Size(35, 40);
            this.labelNumberHL.TabIndex = 0;
            this.labelNumberHL.Text = "4";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(184, 41);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 58);
            this.label35.TabIndex = 0;
            this.label35.Text = "/";
            // 
            // panelTS
            // 
            this.panelTS.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelTS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTS.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTS.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelTS.BorderRadius = 5;
            this.panelTS.BorderSize = 0;
            this.panelTS.Controls.Add(this.label45);
            this.panelTS.Controls.Add(this.label23);
            this.panelTS.Controls.Add(this.labelNumberTS);
            this.panelTS.Controls.Add(this.label44);
            this.panelTS.ForeColor = System.Drawing.Color.White;
            this.panelTS.Location = new System.Drawing.Point(572, 598);
            this.panelTS.Name = "panelTS";
            this.panelTS.Size = new System.Drawing.Size(400, 120);
            this.panelTS.TabIndex = 0;
            this.panelTS.TextColor = System.Drawing.Color.White;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(214, 65);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 40);
            this.label45.TabIndex = 0;
            this.label45.Text = "4";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(130, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(150, 23);
            this.label23.TabIndex = 0;
            this.label23.Text = "XM TRUNG SƠN";
            // 
            // labelNumberTS
            // 
            this.labelNumberTS.AutoSize = true;
            this.labelNumberTS.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberTS.Location = new System.Drawing.Point(147, 48);
            this.labelNumberTS.Name = "labelNumberTS";
            this.labelNumberTS.Size = new System.Drawing.Size(35, 40);
            this.labelNumberTS.TabIndex = 0;
            this.labelNumberTS.Text = "4";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(178, 41);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(47, 58);
            this.label44.TabIndex = 0;
            this.label44.Text = "/";
            // 
            // panelVN
            // 
            this.panelVN.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelVN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelVN.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelVN.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelVN.BorderRadius = 5;
            this.panelVN.BorderSize = 0;
            this.panelVN.Controls.Add(this.label46);
            this.panelVN.Controls.Add(this.label22);
            this.panelVN.Controls.Add(this.labelNumberVN);
            this.panelVN.Controls.Add(this.label36);
            this.panelVN.ForeColor = System.Drawing.Color.White;
            this.panelVN.Location = new System.Drawing.Point(12, 598);
            this.panelVN.Name = "panelVN";
            this.panelVN.Size = new System.Drawing.Size(400, 120);
            this.panelVN.TabIndex = 0;
            this.panelVN.TextColor = System.Drawing.Color.White;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(188, 65);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 40);
            this.label46.TabIndex = 0;
            this.label46.Text = "4";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(91, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(200, 23);
            this.label22.TabIndex = 0;
            this.label22.Text = "XM VICEM VẠN NINH";
            // 
            // labelNumberVN
            // 
            this.labelNumberVN.AutoSize = true;
            this.labelNumberVN.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberVN.Location = new System.Drawing.Point(121, 48);
            this.labelNumberVN.Name = "labelNumberVN";
            this.labelNumberVN.Size = new System.Drawing.Size(35, 40);
            this.labelNumberVN.TabIndex = 0;
            this.labelNumberVN.Text = "4";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(152, 41);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(47, 58);
            this.label36.TabIndex = 0;
            this.label36.Text = "/";
            // 
            // panelVicemHV
            // 
            this.panelVicemHV.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelVicemHV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelVicemHV.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelVicemHV.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelVicemHV.BorderRadius = 5;
            this.panelVicemHV.BorderSize = 0;
            this.panelVicemHV.Controls.Add(this.label40);
            this.panelVicemHV.Controls.Add(this.labelNumberHV);
            this.panelVicemHV.Controls.Add(this.label27);
            this.panelVicemHV.Controls.Add(this.label17);
            this.panelVicemHV.ForeColor = System.Drawing.Color.White;
            this.panelVicemHV.Location = new System.Drawing.Point(12, 345);
            this.panelVicemHV.Name = "panelVicemHV";
            this.panelVicemHV.Size = new System.Drawing.Size(220, 120);
            this.panelVicemHV.TabIndex = 0;
            this.panelVicemHV.TextColor = System.Drawing.Color.White;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(114, 68);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(35, 40);
            this.label40.TabIndex = 0;
            this.label40.Text = "2";
            // 
            // labelNumberHV
            // 
            this.labelNumberHV.AutoSize = true;
            this.labelNumberHV.Font = new System.Drawing.Font("Century Gothic", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberHV.Location = new System.Drawing.Point(47, 51);
            this.labelNumberHV.Name = "labelNumberHV";
            this.labelNumberHV.Size = new System.Drawing.Size(35, 40);
            this.labelNumberHV.TabIndex = 0;
            this.labelNumberHV.Text = "2";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(78, 44);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 58);
            this.label27.TabIndex = 0;
            this.label27.Text = "/";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(30, 21);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(151, 23);
            this.label17.TabIndex = 0;
            this.label17.Text = "VICEM HẢI VÂN";
            // 
            // panelNhomCT
            // 
            this.panelNhomCT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelNhomCT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelNhomCT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelNhomCT.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelNhomCT.BorderRadius = 5;
            this.panelNhomCT.BorderSize = 0;
            this.panelNhomCT.Controls.Add(this.label9);
            this.panelNhomCT.Controls.Add(this.label10);
            this.panelNhomCT.ForeColor = System.Drawing.Color.White;
            this.panelNhomCT.Location = new System.Drawing.Point(12, 152);
            this.panelNhomCT.Name = "panelNhomCT";
            this.panelNhomCT.Size = new System.Drawing.Size(200, 80);
            this.panelNhomCT.TabIndex = 0;
            this.panelNhomCT.TextColor = System.Drawing.Color.White;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(29, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 23);
            this.label9.TabIndex = 1;
            this.label9.Text = " CHIẾN THẮNG";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(61, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 23);
            this.label10.TabIndex = 2;
            this.label10.Text = "NHÔM";
            // 
            // panelCuongThinh
            // 
            this.panelCuongThinh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelCuongThinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCuongThinh.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCuongThinh.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelCuongThinh.BorderRadius = 5;
            this.panelCuongThinh.BorderSize = 0;
            this.panelCuongThinh.Controls.Add(this.label26);
            this.panelCuongThinh.Controls.Add(this.label2);
            this.panelCuongThinh.ForeColor = System.Drawing.Color.White;
            this.panelCuongThinh.Location = new System.Drawing.Point(276, 26);
            this.panelCuongThinh.Name = "panelCuongThinh";
            this.panelCuongThinh.Padding = new System.Windows.Forms.Padding(1);
            this.panelCuongThinh.Size = new System.Drawing.Size(200, 80);
            this.panelCuongThinh.TabIndex = 0;
            this.panelCuongThinh.TextColor = System.Drawing.Color.White;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(38, 38);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(140, 23);
            this.label26.TabIndex = 0;
            this.label26.Text = "CƯỜNG THỊNH";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(80, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "XM";
            // 
            // panelDuyenLinh
            // 
            this.panelDuyenLinh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelDuyenLinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelDuyenLinh.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelDuyenLinh.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.panelDuyenLinh.BorderRadius = 5;
            this.panelDuyenLinh.BorderSize = 0;
            this.panelDuyenLinh.Controls.Add(this.label24);
            this.panelDuyenLinh.Controls.Add(this.label1);
            this.panelDuyenLinh.ForeColor = System.Drawing.Color.White;
            this.panelDuyenLinh.Location = new System.Drawing.Point(12, 26);
            this.panelDuyenLinh.Name = "panelDuyenLinh";
            this.panelDuyenLinh.Padding = new System.Windows.Forms.Padding(1);
            this.panelDuyenLinh.Size = new System.Drawing.Size(200, 80);
            this.panelDuyenLinh.TabIndex = 0;
            this.panelDuyenLinh.TextColor = System.Drawing.Color.White;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(40, 38);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(117, 23);
            this.label24.TabIndex = 0;
            this.label24.Text = "DUYÊN LINH";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(74, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "XM";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Stations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1582, 753);
            this.Controls.Add(this.panelNguyetMinh2);
            this.Controls.Add(this.panelAriyana);
            this.Controls.Add(this.panelGiayAH);
            this.Controls.Add(this.panelSabeco);
            this.Controls.Add(this.panelTC1);
            this.Controls.Add(this.panelMinhTien);
            this.Controls.Add(this.panelMinhTuan);
            this.Controls.Add(this.panelETC);
            this.Controls.Add(this.panelPhuTan);
            this.Controls.Add(this.panelNhomMD);
            this.Controls.Add(this.panelTA);
            this.Controls.Add(this.panelAcecook);
            this.Controls.Add(this.panelTC3);
            this.Controls.Add(this.panelSaiSon);
            this.Controls.Add(this.panelHL);
            this.Controls.Add(this.panelTS);
            this.Controls.Add(this.panelVN);
            this.Controls.Add(this.panelVicemHV);
            this.Controls.Add(this.panelNhomCT);
            this.Controls.Add(this.panelCuongThinh);
            this.Controls.Add(this.panelDuyenLinh);
            this.Name = "Stations";
            this.Text = "Stations Monitor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Stations_Activated);
            this.Load += new System.EventHandler(this.Stations_Load);
            this.panelNguyetMinh2.ResumeLayout(false);
            this.panelNguyetMinh2.PerformLayout();
            this.panelAriyana.ResumeLayout(false);
            this.panelAriyana.PerformLayout();
            this.panelGiayAH.ResumeLayout(false);
            this.panelGiayAH.PerformLayout();
            this.panelSabeco.ResumeLayout(false);
            this.panelSabeco.PerformLayout();
            this.panelTC1.ResumeLayout(false);
            this.panelTC1.PerformLayout();
            this.panelMinhTien.ResumeLayout(false);
            this.panelMinhTien.PerformLayout();
            this.panelMinhTuan.ResumeLayout(false);
            this.panelMinhTuan.PerformLayout();
            this.panelETC.ResumeLayout(false);
            this.panelETC.PerformLayout();
            this.panelPhuTan.ResumeLayout(false);
            this.panelPhuTan.PerformLayout();
            this.panelNhomMD.ResumeLayout(false);
            this.panelNhomMD.PerformLayout();
            this.panelTA.ResumeLayout(false);
            this.panelTA.PerformLayout();
            this.panelAcecook.ResumeLayout(false);
            this.panelAcecook.PerformLayout();
            this.panelTC3.ResumeLayout(false);
            this.panelTC3.PerformLayout();
            this.panelSaiSon.ResumeLayout(false);
            this.panelSaiSon.PerformLayout();
            this.panelHL.ResumeLayout(false);
            this.panelHL.PerformLayout();
            this.panelTS.ResumeLayout(false);
            this.panelTS.PerformLayout();
            this.panelVN.ResumeLayout(false);
            this.panelVN.PerformLayout();
            this.panelVicemHV.ResumeLayout(false);
            this.panelVicemHV.PerformLayout();
            this.panelNhomCT.ResumeLayout(false);
            this.panelNhomCT.PerformLayout();
            this.panelCuongThinh.ResumeLayout(false);
            this.panelCuongThinh.PerformLayout();
            this.panelDuyenLinh.ResumeLayout(false);
            this.panelDuyenLinh.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private CustemItems.CustomPanel panelDuyenLinh;
        private CustemItems.CustomPanel panelCuongThinh;
        private CustemItems.CustomPanel panelPhuTan;
        private CustemItems.CustomPanel panelMinhTuan;
        private CustemItems.CustomPanel panelTC1;
        private CustemItems.CustomPanel panelGiayAH;
        private CustemItems.CustomPanel panelNguyetMinh2;
        private CustemItems.CustomPanel panelNhomCT;
        private CustemItems.CustomPanel panelNhomMD;
        private CustemItems.CustomPanel panelETC;
        private CustemItems.CustomPanel panelMinhTien;
        private CustemItems.CustomPanel panelSabeco;
        private CustemItems.CustomPanel panelAriyana;
        private CustemItems.CustomPanel panelVicemHV;
        private CustemItems.CustomPanel panelSaiSon;
        private CustemItems.CustomPanel panelTC3;
        private CustemItems.CustomPanel panelVN;
        private CustemItems.CustomPanel panelTS;
        private CustemItems.CustomPanel panelHL;
        private CustemItems.CustomPanel panelAcecook;
        private System.Windows.Forms.Label label1;
        private CustemItems.CustomPanel panelTA;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label labelNumberPhuTan;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label labelThuyAnh;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label labelNumberAcecook;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label labelNumberTC3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label labelNumberSaiSon;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label labelNumberHL;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label labelNumberTS;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label labelNumberVN;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label labelNumberHV;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Timer timer2;
    }
}