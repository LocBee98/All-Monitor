# All-Monitor
Phần mềm giám sát truyền dẫn
# Mô tả phần mềm
Kiểm tra tình trạng truyền dẫn file từ 21 nhà máy về Sở TNMT các tỉnh.
Sử dụng FTP protocol truy cập vào FTP server của các sở TNMT để kiểm tra tình trạng truyền dẫn của các nhà máy.
# Tính năng: 
Giám sát trực tuyến, thông báo trên giao diện khi mất tín hiệu truyền dẫn, cảnh báo qua email.

# Bảo mật
Vì lý do bảo mật dữ liệu, các ftp server của các sở và công ty đã được ẩn.
# Hình ảnh thực tế trong folder /Pictures App
